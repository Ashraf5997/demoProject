import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-auth-employees-array',
  templateUrl: './auth-employees-array.component.html',
  styleUrls: ['./auth-employees-array.component.css']
})
export class AuthEmployeesArrayComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
