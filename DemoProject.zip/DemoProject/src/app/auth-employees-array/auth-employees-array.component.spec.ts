import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AuthEmployeesArrayComponent } from './auth-employees-array.component';

describe('AuthEmployeesArrayComponent', () => {
  let component: AuthEmployeesArrayComponent;
  let fixture: ComponentFixture<AuthEmployeesArrayComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AuthEmployeesArrayComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AuthEmployeesArrayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
