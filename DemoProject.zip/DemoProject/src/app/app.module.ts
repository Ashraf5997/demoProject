import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { ListofemployeesComponent } from './listofemployees/listofemployees.component';
import { AdminheaderComponent } from './adminheader/adminheader.component';
import { AddnewemployeesComponent } from './addnewemployees/addnewemployees.component';
import { SettinglandingComponent } from './settinglanding/settinglanding.component';
import { ViewempdetailComponent } from './viewempdetail/viewempdetail.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { LandingpageComponent } from './landingpage/landingpage.component';
import { HttpClientModule } from '@angular/common/http';
import { AuthEmployeesArrayComponent } from './auth-employees-array/auth-employees-array.component';
import { EmployeeService } from './employee.service';
import { User } from './user';
import { AuthGuard } from './auth.guard';






@NgModule({
  declarations: [
   AppComponent,
   LoginComponent,
   ListofemployeesComponent,
   AdminheaderComponent,
   AddnewemployeesComponent,
   SettinglandingComponent,
   ViewempdetailComponent,
   PagenotfoundComponent,
   LandingpageComponent,
   AuthEmployeesArrayComponent,
   
  ],
  
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    FormsModule,
    BrowserAnimationsModule,
    BsDatepickerModule.forRoot(),
  
    

  ],
  providers: [EmployeeService,AuthGuard],
  bootstrap: [AppComponent],
})
export class AppModule { }
