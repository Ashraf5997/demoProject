import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { ListofemployeesComponent } from './listofemployees/listofemployees.component';
import { AdminheaderComponent } from './adminheader/adminheader.component';
import { AddnewemployeesComponent } from './addnewemployees/addnewemployees.component';
import { SettinglandingComponent } from './settinglanding/settinglanding.component';
import { ViewempdetailComponent } from './viewempdetail/viewempdetail.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { LandingpageComponent } from './landingpage/landingpage.component';
import { AuthGuard } from './auth.guard';

const routes: Routes = [
{ path : '',component:LoginComponent},
{ path : 'login',component:LoginComponent},
{ path : 'listofemployees',component:ListofemployeesComponent/*,canActivate:[AuthGuard]*/},
{ path : 'adminheader',component:AdminheaderComponent/*,canActivate:[AuthGuard] */},
{ path : 'addnewemployees',component:AddnewemployeesComponent,/*canActivate:[AuthGuard]*/},
{ path : 'setting',component:SettinglandingComponent,/*canActivate:[AuthGuard]*/},
{ path : 'viewempdetail',component:ViewempdetailComponent,/*canActivate:[AuthGuard]*/ },
{ path : 'landingpage',component:LandingpageComponent,/*canActivate:[AuthGuard]*/ },
{ path : '**',component:PagenotfoundComponent},



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule { 
 

}


