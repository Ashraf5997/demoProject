import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';


@Component({
  selector: 'app-landingpage',
  templateUrl: './landingpage.component.html',
  styleUrls: ['./landingpage.component.css']
})
export class LandingpageComponent implements OnInit {
 public email;
 public name;

  constructor(private empservice:EmployeeService) 
  {  
      // this. data=empservice.name1;
       //alert(empservice.name1)
       //localStorage('dat','data')
          // alert(empservice.getuserdata())
       this.name  = empservice.getusername();
       this.email = empservice.getuseremail();
  }

  
 
  ngOnInit(): void  {
  }

Logout()
{

 this.empservice.setLogout();
}


}
