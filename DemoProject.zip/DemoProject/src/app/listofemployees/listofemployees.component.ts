import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listofemployees',
  templateUrl: './listofemployees.component.html',
  styleUrls: ['./listofemployees.component.css']
})
export class ListofemployeesComponent implements OnInit {


public employees=[
 {
    id:'ICT001',
    name:'Ashraf',
    email:'ashrafjamal5997@gmail',
    designation:'Front-end developer',
    photopath:'../assets/images/ashraf.jpg'
 },

 {
   id:'ICT002',
   name:'Zamal',
   email:'ashrafjamal6997@gmail.com',
    designation:'Front-end developer',
   photopath:'../assets/images/jamal.jpg'
 },
 {
    id:'ICT003',
    name:'Ashraf',
    email:'ashrafjamal5997@gmail',
     designation:'Front-end developer',
     photopath:'../assets/images/ashraf.jpg'
 }
];

  constructor() { }

  ngOnInit(): void {
  }

}
