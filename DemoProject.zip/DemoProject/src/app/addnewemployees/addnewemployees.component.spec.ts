import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddnewemployeesComponent } from './addnewemployees.component';

describe('AddnewemployeesComponent', () => {
  let component: AddnewemployeesComponent;
  let fixture: ComponentFixture<AddnewemployeesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddnewemployeesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddnewemployeesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
