import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';


@Component({
  selector: 'app-addnewemployees',
  templateUrl: './addnewemployees.component.html',
  styleUrls: ['./addnewemployees.component.css']
})
export class AddnewemployeesComponent implements OnInit {

public fullname=""


saveemployees(employeeForm:NgForm):void
{
	console.log(employeeForm.value);
	alert("hi");
}




  constructor() { }

  ngOnInit(): void {
  }

}
