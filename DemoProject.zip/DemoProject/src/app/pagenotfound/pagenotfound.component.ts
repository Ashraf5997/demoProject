import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-pagenotfound',
  templateUrl: './pagenotfound.component.html',
  styleUrls: ['./pagenotfound.component.css']
})
export class PagenotfoundComponent implements OnInit {

  constructor(private empservice: EmployeeService,private router:Router) { }

  ngOnInit(): void {
  }
  isloggedin()
  {
     if(this.empservice.isLoggedIn){ this.router.navigate(['/landingpage'])}
     else { this.router.navigate(['/login']);}
  }
  

}
