import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewempdetailComponent } from './viewempdetail.component';

describe('ViewempdetailComponent', () => {
  let component: ViewempdetailComponent;
  let fixture: ComponentFixture<ViewempdetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewempdetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewempdetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
