import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewempdetail',
  templateUrl: './viewempdetail.component.html',
  styleUrls: ['./viewempdetail.component.css']
})
export class ViewempdetailComponent implements OnInit {


public showModel=""

public employees=[
 {
    id:'ICT001',
    name:'Ashraf',
    email:'ashrafjamal5997@gmail',
    designation:'Front-end developer',
    photopath:'../assets/images/ashraf.jpg',
    access:'read&write',
    contact:'56466446',
    dob:'55/55/5425',
    gender:'male',
    address:'kolkata',
    experiance:'fresher'
 },
 {
    id:'ICT001',
    name:'Ashraf',
    email:'ashrafjamal5997@gmail',
    designation:'Front-end developer',
    photopath:'../assets/images/ashraf.jpg',
    access:'read&write',
    contact:'56466446',
    dob:'55/55/5425',
    gender:'male',
    address:'kolkata',
    experiance:'fresher'
 },
 

];


  constructor() { }

  ngOnInit(): void {
  }

}
