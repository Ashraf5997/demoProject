import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { User } from './user';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';



//import {Observable} from 'rxjs-compat/observable/ArrayObservable';

  interface mydata{
	success:boolean,
	message:string

}

@Injectable({
  providedIn: 'root'
}) 
export class EmployeeService {

private loggedInStatus=JSON.parse(localStorage.getItem('loggedIn') ||'false'); 



//private auth_url ="/assets/data/emp.json";
//private auth_url='http://localhost:9090/userauthentication/'+username+'/'+password;

  constructor(private httpclient: HttpClient,private router:Router) { }

  private extractData(res:Response){
       return res || {};
    }

    private handleError(error:any):Promise<any>{
      return Promise.reject(error.message || error);
    }

  login(username:any,password:any):Promise<any>{


      console.log("Inside the checkLogIn function = ");
      console.log(" username = "+username);
      console.log(" password = "+password);


      var myHeaders = new HttpHeaders({'Access-Control-Allow-Origin':'*'
      ,'Access-Control-Allow-Methods':'POST, GET, OPTIONS, PUT'});
       alert("username ="+ username+"  "+"password ="+ password)
       let url = 'http://localhost:9090/userauthentication/'+username+'/'+password;
      
         alert(url)

      return this.httpclient.get(url,{headers: myHeaders }).toPromise().then(this.extractData).catch(this.handleError);


  }

  setLogout()
  {
     localStorage.removeItem('loggedIn');
     this.router.navigate(['/login']);
  } 

  get isLoggedIn()
  { 
     return JSON.parse(localStorage.getItem('loggedIn')||this.loggedInStatus.toString())
     return this.loggedInStatus;
  }

  storeuserdetail(dats)
  {
    
   var usr=JSON.parse(JSON.stringify(dats));
   // alert(usr)
   // localStorage.setItem('name',usr.fullname);
   // var email=usr.email;
   // localStorage.setItem('email',usr.email);
   // localStorage.getItem('name')
  
  }
  getusername()  {  return localStorage.getItem('name');  }
  getuseremail() {  return localStorage.getItem('email'); }
  
  setLoggedIn(value:boolean)
  {
    this.loggedInStatus=value;
    localStorage.setItem('loggedIn','true');
  }

}
