import { Component, OnInit } from '@angular/core';
import { Observable } from "rxjs";
import { EmployeeService } from '../employee.service';
import { User } from '../user';
import { AppRoutingModule } from '../app-routing.module';
import { Router } from '@angular/router';

@Component({
             selector: 'app-login',
             templateUrl: './login.component.html',
             styleUrls: ['./login.component.css']
           })

export class LoginComponent implements OnInit
{

 
 email="";
 password="";
 invalidLogin="false";
 status="";
 errormsg1="";
 username="";
usr="";
   public datas;
   constructor( private empservice:EmployeeService ,private router:Router) {}

  ngOnInit()
      {
      }

  checkLogin()
  {
  
      if( this.email=="" || this.password=="")
      {
           this. errormsg1= "Please insert your credentials";
           this.status="true";  
      }
      else
      { 
           
          
            this.empservice.login(this.email,this.password).then(
               response=>{
                  console.log(response);
                  alert(response);
                  this.router.navigateByUrl("/landingpage");

                } ).catch(e=>{
                    alert(e);
                    this.errormsg1=e;
                    console.log("ssss");
               
                    });      

      }
  }
}

   







/*
     if(this.datas)
                {  
                      // this.usr=JSON.stringify(this.datas);
                   this.usr=JSON.stringify(this.datas);
                    alert("inside")
                 //sessionStorage.setItem("credential",JSON.stringify(this.datas));
                   this.empservice.setLoggedIn( true );
                   this.empservice.storeuserdetail(this.datas)
                   this.router.navigate(['landingpage']);  
                }
                else
                {
                    this.errormsg1="invalid email/password";
                    this.status="true";
                //  window.alert(data.message);*/