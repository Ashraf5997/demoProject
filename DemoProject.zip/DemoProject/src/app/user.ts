
/*
constructor( 
 
           ){}
}b
*/

export class User
{
        
                    fullname         :  string ;
                     app_id          :  string ;
                     email           :  string ;
                     dateofbirth     :  string ;
                     contactnumber   :  number ;
                    accessmode       :  string ;
                     address         :  string ;
                    
                     createdby       :  string ;
                     gender          :  string ;
                     modifyby        :  string ;   
}