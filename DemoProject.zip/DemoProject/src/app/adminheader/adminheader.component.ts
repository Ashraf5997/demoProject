import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';
import { EmployeeService } from '../employee.service';


@Component({
  selector: 'app-adminheader',
  templateUrl: './adminheader.component.html',
  styleUrls: ['./adminheader.component.css']
})
export class AdminheaderComponent implements OnInit {


 constructor(private empservice:EmployeeService,private router:Router) { }

employees: any;

public string1="";
public string2=" ";
public mycolor="";

onMouseover(name)
{
   this.mycolor="#CCD1D1"
   if( name=="Link1")     { this.string1="Link1";this.string2="This page is about sfdajsdfajdfa asdfad "}
   else if( name=="Link2")   {	this.string1="List of users"; this.string2="This page contains list of all the employees"}	
   else if( name=="Link3")   {  this.string1="Gallery"; this.string2="This page contains images "}
   else if( name=="Link4")   {  this.string1="Link4"; this.string2="This page is about djdgad "}
   else if( name=="Link5")   {  this.string1="Link5"; this.string2="This page is abpot nmnbvc "}
   else if( name=="Link6")   {  this.string1="Setting"; this.string2="This page contains Insert , Edit and Delete option"}
	
}
onMouseout()
{
	this.string1=" ";
	this.string2=" ";
	this.mycolor="#D6DBDF";
}

Logout(){ this.empservice.setLogout();}



  ngOnInit(): void {



  }

}
