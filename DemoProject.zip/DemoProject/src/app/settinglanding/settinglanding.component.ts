import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-settinglanding',
  templateUrl: './settinglanding.component.html',
  styleUrls: ['./settinglanding.component.css']
})
export class SettinglandingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
