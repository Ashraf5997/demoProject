import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SettinglandingComponent } from './settinglanding.component';

describe('SettinglandingComponent', () => {
  let component: SettinglandingComponent;
  let fixture: ComponentFixture<SettinglandingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SettinglandingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SettinglandingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
